let container = document.getElementById('container')

setTimeout(() => {
	container.classList.add('animar')
}, 200)